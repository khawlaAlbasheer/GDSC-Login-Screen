import 'package:flutter/material.dart';

class CustomIcons {
  static const IconData twitter = IconData(0xe900, fontFamily: "CustomIcons");
  static const IconData facebook = IconData(0xe901, fontFamily: "CustomIcons");
  static const IconData Google = IconData(0xe902, fontFamily: "CustomIcons");
  static const IconData email = IconData(0xe0be, fontFamily: "MaterialIcons");
}
